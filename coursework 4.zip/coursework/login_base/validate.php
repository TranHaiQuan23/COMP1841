<?php
session_start();
require_once __DIR__ . '/../includes/DatabaseConnection.php';
require_once __DIR__ . '/../includes/DatabaseFunctions.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Call the loginUser function
    $result = loginUser($pdo, $email, $password);

    // Handle the result
    if (!$result['status']) {
        switch ($result['error']) {
            case 'empty':
                header("Location: login.html?error=empty");
                break;
            case 'not_authorised':
                header("Location: notauthorised.php");
                break;
            case 'wrong_password':
                header("Location: wrongpassword.php");
                break;
            case 'user_not_found':
                header("Location: notauthorised.php");
                break;
        }
        exit;
    }

    // Redirect to the main page on successful login
    header("Location: ../index.php");
    exit;
} else {
    header("Location: login.html");
    exit;
}
?>