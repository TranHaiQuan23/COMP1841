<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Include required files
require_once __DIR__ . '/../admin_base/admin_check.php';
require_once __DIR__ . '/../includes/DatabaseConnection.php';
require_once __DIR__ . '/../includes/DatabaseFunctions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];

    // Update the user profile
    if (updateUserProfile($pdo, $_SESSION['user_id'], $name, $email)) {
        $successMessage = 'Profile updated successfully!';
    } else {
        $errorMessage = 'Failed to update profile. Please try again.';
    }
}

// Fetch only the logged-in user's image and details
$avatar = getUserAvatar($pdo, $_SESSION['user_id']);
$user = getUserById($pdo, $_SESSION['user_id']);


$title = 'Questions';
$totalQuestions = totalQuestions($pdo);

ob_start();
include __DIR__ . '/../templates/admin_profile.html.php';
$output = ob_get_clean();
include __DIR__ . '/../templates/admin_layout.html.php';
?>
