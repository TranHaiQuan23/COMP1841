<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once __DIR__ . '/../admin_base/admin_check.php';
require_once __DIR__ . '/../includes/DatabaseConnection.php';
require_once __DIR__ . '/../includes/DatabaseFunctions.php'; 

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login_base/notauthorised.php");
    exit;
}

// Ensure the user is a teacher
$userRole = getUserRole($pdo, $_SESSION['user_id']);
if ($userRole !== 'teacher') {
    header("Location: login_base/notauthorised.php");
    exit;
}

if (isset($_POST['question_id'])) {
    // Get the question ID from the POST request
    $question_id = (int) $_POST['question_id'];

    if (deleteQuestion1($pdo, $question_id)) {
        header('Location: question.php?msg=Question deleted successfully');
        exit;
    } else {
        $error = 'An error occurred while deleting the question.';
    }
}

$avatar = getUserAvatar($pdo, $_SESSION['user_id']);
?>

