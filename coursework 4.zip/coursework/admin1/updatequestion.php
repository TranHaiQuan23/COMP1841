<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Include required files
require_once __DIR__ . '/../admin_base/admin_check.php';
require_once __DIR__ . '/../includes/DatabaseConnection.php';
require_once __DIR__ . '/../includes/DatabaseFunctions.php';


// Check if question ID is provided
if (!isset($_GET['id'])) {
    die('Question ID not provided.');
}

$questionId = $_GET['id'];

// Fetch the question to be updated
$questions = getQuestionById($pdo, $questionId);

if (!$questions) {
    die('Question not found.');
}

// Check if form is submitted
if (isset($_POST['questionText'], $_POST['questionId'])) {
    $questionId = $_POST['questionId'];
    $questionText = $_POST['questionText'];
    $imagePath = $questions['image_q']; // Keep current image if not updated

    // Check if a new file is uploaded
    if (isset($_FILES['fileToUpload']) && $_FILES['fileToUpload']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "images/";
        $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if image file is an actual image
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if ($check !== false) {
            error_log("File is an image.");
        } else {
            error_log("File is not an image.");
            $uploadOk = 0; // Not an image
        }

        // Check file size
        if ($_FILES["fileToUpload"]["size"] > 500000) {
            error_log("File too large.");
            $uploadOk = 0; // File too large
        }

        // Allow certain file formats
        if (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
            error_log("Invalid file format.");
            $uploadOk = 0; // Invalid file format
        }

        // Attempt to upload file if all checks are passed
        if ($uploadOk == 1) {
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                $imagePath = basename($_FILES["fileToUpload"]["name"]); // Update image path
                error_log("Uploaded image path: $imagePath");
            } else {
                error_log("Error uploading file.");
            }
        } else {
            error_log("File upload failed.");
        }
    } else {
        error_log("No file uploaded or error during upload: " . $_FILES['fileToUpload']['error']);
    }

    // Log the image path and other data before the update
    error_log("Updating question ID: $questionId with text: $questionText and image: $imagePath");

    // Update the question with new text and image path
    $updateSuccess = updateQuestion($pdo, $_SESSION['user_id'], $questionId, $questionText, $imagePath);

    // Check the result of the update
    if ($updateSuccess) {
        header('Location: question.php');
        exit; // Always call exit after a redirect
    } else {
        $error = "Failed to update the question. You may not be the owner or the question was not found.";
        error_log($error); // Log the error message
    }
}

// Fetch total questions
$totalQuestions = totalQuestions($pdo);

// Fetch only the logged-in user's image
$avatar = getUserAvatar($pdo, $_SESSION['user_id']);

ob_start();
include __DIR__ . '/../templates/admin_updatequestion.html.php';
$output = ob_get_clean();
include __DIR__ . '/../templates/admin_layout.html.php';

?>