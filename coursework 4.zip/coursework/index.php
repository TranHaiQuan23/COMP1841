<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Include required files

require_once __DIR__ . '/login_base/check.php' ;
require_once __DIR__ . '/includes/DatabaseConnection.php';
require_once __DIR__ . '/includes/DatabaseFunctions.php';

$avatar = getUserAvatar($pdo, $_SESSION['user_id']);

// Page title
$title = 'Welcome to Student Service Page.';

// Page content
ob_start();
include __DIR__ . '/templates/home.html.php';
$output = ob_get_clean();

// Pass avatar to layout
$GLOBALS['avatar'] = $avatar;

// Include layout with the output
include __DIR__ . '/templates/layout.html.php';
?>
