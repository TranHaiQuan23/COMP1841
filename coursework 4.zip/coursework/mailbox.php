<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Include required files
require_once __DIR__ . '/login_base/check.php';
require_once __DIR__ . '/includes/DatabaseConnection.php';
require_once __DIR__ . '/includes/DatabaseFunctions.php';

// Fetch only the logged-in user's image
$avatar = getUserAvatar($pdo, $_SESSION['user_id']);

// Fetch received messages
$messages = getReceivedMessages($pdo, $_SESSION['user_id']);


$title = 'Mailbox';
ob_start();
include __DIR__ . '/templates/mailbox.html.php'; // Create this template to display messages
$output = ob_get_clean();
include __DIR__ . '/templates/layout.html.php';
?>