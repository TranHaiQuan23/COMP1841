<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Include required files
require_once __DIR__ . '/login_base/check.php';
require_once __DIR__ . '/includes/DatabaseConnection.php';
require_once __DIR__ . '/includes/DatabaseFunctions.php'; 

if (isset($_POST['question_id'])) {
    try {
        // Get the question ID from the POST request
        $question_id = (int) $_POST['question_id'];

        // Call deleteQuestion function and check if it was successful
        if (deleteQuestion($pdo, $_SESSION['user_id'], $question_id)) {
            // Redirect after successful deletion
            header('Location: question.php');
            exit;
        } else {
            echo 'You do not have permission to delete this question or it does not exist.';
        }
    } catch (PDOException $e) {
        echo 'An error occurred: ' . htmlspecialchars($e->getMessage());
    }
}


// // Fetch only the logged-in user's image
$avatar = getUserAvatar($pdo, $_SESSION['user_id']);