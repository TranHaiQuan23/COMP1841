<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Include required files
require_once __DIR__ . '/login_base/check.php';
require_once __DIR__ . '/includes/DatabaseConnection.php';
require_once __DIR__ . '/includes/DatabaseFunctions.php';

// Fetch only the logged-in user's image
$avatar = getUserAvatar($pdo, $_SESSION['user_id']);

// Fetch users 
$users = getUser($pdo);

$title = 'Users';
ob_start();
include __DIR__ . '/templates/user.html.php';
$output = ob_get_clean();
include __DIR__ . '/templates/layout.html.php';
?>