<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: admin_notauthorised.php");
    exit;
    
} else{
    header("Location: ../admin/home.php");
}
?>

