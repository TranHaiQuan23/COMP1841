<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Failed</title>
    <link rel="stylesheet" href="admin_logincwr.css">
</head>
<body>
    <div class="container">
        <div class="login-card">
            <h2>Login Failed</h2>
            <p>Incorrect password.</p>
            <a href="admin_login.html">Back to Login</a>
        </div>
    </div>
</body>
</html>