<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

require_once __DIR__ . '/login_base/check.php';
require_once __DIR__ . '/includes/DatabaseConnection.php';
require_once __DIR__ . '/includes/DatabaseFunctions.php';

// Fetch user's avatar and teachers
$avatar = getUserAvatar($pdo, $_SESSION['user_id']);
$teachers = getUser($pdo);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $teacherId = $_POST['teacher_id'] ?? null;
    $messageText = $_POST['message_text'] ?? null;

    // Ensure both fields are filled
    if ($teacherId && $messageText) {
        // Insert message into the database
        if (insertMessage($pdo, $_SESSION['user_id'], $teacherId, $messageText)) {
            header('Location: message.php?success=Message sent!');
            exit;
        } else {
            $error = 'Failed to send message. Please try again.';
        }
    } else {
        $error = 'Please select a teacher and enter a message.';
    }
}


$title = 'Message';
ob_start();
include __DIR__ . '/templates/message.html.php';
$output = ob_get_clean();
include __DIR__ . '/templates/layout.html.php';
?>