<div class="dashboard">Message</div>
<div class="container3-message">
    <?php if (isset($error)): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php elseif (isset($_GET['success'])): ?>
        <p class="success"><?= htmlspecialchars($_GET['success']) ?></p>
    <?php endif; ?>

    <form action="message.php" method="post">
        <label for="teacher_id" class="teacher_email">Select Teacher:</label>
        <select name="teacher_id" id="teacher_id" class="message1" required>
            <option value="">Select Teacher</option>
            <?php foreach ($teachers as $teacher): ?>
                <option value="<?= htmlspecialchars($teacher['id'], ENT_QUOTES, 'UTF-8'); ?>">
                    <?= htmlspecialchars($teacher['name'], ENT_QUOTES, 'UTF-8'); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="message_text" class="message_title">Message:</label>
        <textarea name="message_text" id="message_text" class="message_text" placeholder="Share your thoughts" required></textarea>
        
        <input type="submit" value="Send Message" class="button-1">
    </form>
</div>