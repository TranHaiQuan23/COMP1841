<div class="dashboard">Mailbox</div>
<div class="container3-message">
    <?php if ($messages): ?>
        <?php foreach ($messages as $message): ?>
            <blockquote>
                <strong>From:</strong> <?= htmlspecialchars($message['sender_name'], ENT_QUOTES, 'UTF-8'); ?><br>
                <strong>Message:</strong> <?= htmlspecialchars($message['text_m'], ENT_QUOTES, 'UTF-8'); ?><br>
                <strong>Date:</strong> <?= htmlspecialchars($message['date'], ENT_QUOTES, 'UTF-8'); ?>
            </blockquote>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No messages received.</p>
    <?php endif; ?>
</div>