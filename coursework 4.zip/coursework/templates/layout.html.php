<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="indexcwr.css">
</head>
<style>
</style>

<body class="home-layout">

    <div class="sidebar">    
        <img class="ava" src="<?= htmlspecialchars($avatar, ENT_QUOTES, 'UTF-8'); ?>" alt="User Avatar">        <br>
        <div class="sidebar-items"><a href="home.php">Home</a></div>
        <br>
        <div class="sidebar-items"><a href="user.php">User</a></div>
        <br>
        <div class="sidebar-items"><a href="module.php">Course</a></div>
        <br>
        <div class="sidebar-items"><a href="question.php">Question</a></div>
        <br>
        <div class="sidebar-items"><a href="message.php">Message</a></div>
        <br>
        <div class="sidebar-items"><a href="mailbox.php">Mail box</a></div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <div class="sidebar-items"><a href="profile.php">Profile</a></div>
        <br>
        <div class="sidebar-items"><a href="logout.php">Logout</a></div>
    </div>

    <main>
        <?=$output?>
    </main>
</body>
</html>
