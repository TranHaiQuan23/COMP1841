<form action="" method="post" enctype="multipart/form-data" class="container-question2">
    
    <?php if (!empty($questions['image_q'])): ?>
        <h3>Current Image:</h3>
        <textarea name="questionText"><?= htmlspecialchars($questions['text_q']) ?></textarea>
        <input type="hidden" name="questionId" value="<?= htmlspecialchars($questions['id']) ?>">
    <img class="update-image" src="images/<?= htmlspecialchars($questions['image_q']) ?>" alt="Question Image" style="max-width: 300px;">
    <?php endif; ?>

    <label for="fileToUpload"></label><br>
    <input type="file" name="fileToUpload" accept="image/*">

    <button type="submit">Update Question</button>
</form>

