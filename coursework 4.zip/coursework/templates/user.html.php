
<body>
    <div class="dashboard">Users</div>
    <div class="container-module">
        <?php if(isset($error)): ?>
            <p> <?=$error ?> </p>

        <?php else:
            foreach($users as $user): ?>
            <blockquote>
                <img class="avatar-circle" height="50px" src="images/<?= htmlspecialchars($user['image'], ENT_QUOTES, 'UTF-8') ?>" alt="User Avatar" />
                <?=htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8')?> -
                <?=htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8')?>-
                <?=htmlspecialchars($user['role'], ENT_QUOTES, 'UTF-8')?>
            </blockquote>
        <?php endforeach;
        endif;

        ?>
    </div>
