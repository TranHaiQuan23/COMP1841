<form action="" method="post" enctype="multipart/form-data" class="container-question2">
    
    <h3>Current Module:</h3>
    <textarea name="ModuleName" required><?= htmlspecialchars($Module['name']) ?></textarea> <!-- Correct field name -->
    <input type="hidden" name="ModuleId" value="<?= htmlspecialchars($Module['id']) ?>">

    <button type="submit">Update Module</button>
</form>