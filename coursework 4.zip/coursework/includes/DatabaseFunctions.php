<?php


function query($pdo, $sql, $parameters = []) {
    try {
        $query = $pdo->prepare($sql);
        $query->execute($parameters);
        return $query;
    } catch (PDOException $e) {
        error_log("Database query error: " . $e->getMessage());
        return false; // Return false on error
    }
}

function totalQuestions($pdo) {
    $query = query($pdo,'SELECT COUNT(*) AS count FROM Question');
    $row = $query->fetch(PDO::FETCH_ASSOC); // Fetch associative array
    return $row ? $row['count'] : 0; // Return 0 if no results
}

function getModule($pdo) {
    try {
        $query = query($pdo, 'SELECT * FROM Module'); // No parameters needed
        return $query->fetchAll(PDO::FETCH_ASSOC); // Return all modules as an associative array
    } catch (PDOException $e) {
        return []; // Return an empty array in case of an error
    }
}

function getUser($pdo) {
    try {
        $query = query($pdo, 'SELECT * FROM user'); // No parameters needed
        return $query->fetchAll(PDO::FETCH_ASSOC); // Return all modules as an associative array
    } catch (PDOException $e) {
        return []; // Return an empty array in case of an error
    }
}

function getQuestions($pdo) {
    try {
        $sql ='SELECT 
        Question.id,
        Question.image_q,
        Question.text_q,
        date,
        user.image,
        user.name AS user_name,
        Module.name AS module_name
        FROM Question
        INNER JOIN user ON Question.user_id = user.id
        INNER JOIN Module ON Question.module_id = Module.id';

        
        $query = query($pdo, $sql);
        return $query->fetchAll(PDO::FETCH_ASSOC); // Return all questions as an associative array
    } catch (PDOException $e) {
        return []; // Return an empty array in case of an error
    }
}
function updateQuestion($pdo, $userId, $questionId, $questionText, $imagePath) {
    $sql = "UPDATE Question SET text_q = :text_q, image_q = :image_q WHERE id = :id AND user_id = :user_id";
    $parameters = [
        ':text_q' => $questionText,
        ':image_q' => $imagePath,
        ':id' => $questionId,
        ':user_id' => $userId
    ];
    return query($pdo, $sql, $parameters);
}
function updateModule($pdo, $moduleId, $moduleName) {
    $sql = "UPDATE Module SET name = :name WHERE id = :id"; // Correct table name
    $parameters = [
        ':name' => $moduleName,
        ':id' => $moduleId
    ];
    return query($pdo, $sql, $parameters);
}


function deleteQuestion($pdo, $userId, $questionId) {
    // First, check if the question exists and if the user is the owner
    $stmt = $pdo->prepare('SELECT user_id FROM Question WHERE id = :id');
    $stmt->execute([':id' => $questionId]);
    $question = $stmt->fetch(PDO::FETCH_ASSOC);

    // If the question exists and the user is the owner, proceed to delete
    if ($question && $question['user_id'] == $userId) {
        $parameters = [':id' => $questionId];
        query($pdo, 'DELETE FROM Question WHERE id = :id', $parameters);
        return true; // Indicate successful deletion
    }

    return false; // Indicate failure (either question doesn't exist or user is not the owner)
}

function insertQuestion($pdo, $text_q, $user_id, $module_id, $image_path = null) {
    $query = 'INSERT INTO Question (`text_q`, `date`, `user_id`, `module_id`, `image_q`) VALUES (:text_q, CURDATE(), :user_id, :module_id, :image_path)';
    $parameters = [
        ':text_q' => $text_q,
        ':user_id' => $user_id,
        ':module_id' => $module_id,
        ':image_path' => $image_path // This will now be the path to 'images/'
    ];
    return query($pdo, $query, $parameters); // Optionally return the result
}

function getQuestionById($pdo, $id) {
    $query = 'SELECT * FROM Question WHERE id = :id';
    $stmt = $pdo->prepare($query);
    $stmt->execute([':id' => $id]);
    return $stmt->fetch(PDO::FETCH_ASSOC); // Fetch the question as an associative array
}


function getUserAvatar($pdo, $userId) {
    // Prepare the SQL statement to fetch the user's image
    $stmt = $pdo->prepare('SELECT image FROM user WHERE id = ?');
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Build the avatar path
    if (!empty($user['image'])) {
        return '/COMP1841/coursework/images/' . $user['image'];
    } else {
        return 'images/default-avatar.png'; // Default avatar path
    }
}


function getUserRole($pdo, $userId) {
    $stmt = $pdo->prepare("SELECT role FROM user WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    return $user ? $user['role'] : null; // Return role or null if not found
}

function addModule($pdo, $moduleName) {
    try {
        // Prepare and execute the insert statement
        $stmt = $pdo->prepare("INSERT INTO Module (name) VALUES (?)");
        $stmt->execute([$moduleName]);

        return true; // Indicate success
    } catch (PDOException $e) {
        // Handle error (optional: log the error or return a message)
        return false; // Indicate failure
    }
}

function deleteModule($pdo, $moduleId) {
    try {
        // Prepare and execute the delete statement
        $stmt = $pdo->prepare("DELETE FROM Module WHERE id = ?");
        $stmt->execute([$moduleId]);

        return true; // Indicate success
    } catch (PDOException $e) {
        // Handle error (optional: log the error or return a message)
        return false; // Indicate failure
    }
}

function deleteQuestion1($pdo, $questionId) {
    try {
        // Prepare and execute the delete statement for the specific question
        $stmt = $pdo->prepare("DELETE FROM Question WHERE id = ?");
        $stmt->execute([$questionId]);

        return true; // Indicate success
    } catch (PDOException $e) {
        // Optionally log the error
        error_log($e->getMessage());
        return false; // Indicate failure
    }
}

function adminLogin($pdo, $email, $password) {
    $stmt = $pdo->prepare("SELECT * FROM user WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && $password === $user['password']) {
        return $user; // Return user data if validated
    }

    return false; // Return false if validation fails
}


function checkUserRole($pdo) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        header("Location: login_base/notauthorised.php");
        exit;
    }

    // Fetch user role from the database
    $stmt = $pdo->prepare("SELECT role FROM user WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();

    // Check the user role
    if ($user && $user['role'] === 'teacher') {
        require_once __DIR__ . '/../admin_base/admin_check.php';
    } else {
        require_once __DIR__ . '/../login_base/check.php';
    }
}

function loginUser($pdo, $email, $password) {
    // Check if email and password are provided
    if (empty($email) || empty($password)) {
        return ["status" => false, "error" => "empty"];
    }

    // Prepare and execute the SQL statement to fetch user data
    $stmt = $pdo->prepare("SELECT * FROM user WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Check if user exists
    if ($user) {
        // Verify the password
        if ($password === $user['password']) {
            // Deny access for admin role
            if ($user['role'] === 'teacher') {
                return ["status" => false, "error" => "not_authorised"];
            }

            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email'] = $user['email'];

            return ["status" => true]; // Indicate success
        } else {
            return ["status" => false, "error" => "wrong_password"];
        }
    } else {
        return ["status" => false, "error" => "user_not_found"];
    }
}


function deleteUser($pdo, $userId) {
    try {
        // Prepare and execute the delete statement for the specific question
        $stmt = $pdo->prepare("DELETE FROM user WHERE id = ?");
        $stmt->execute([$userId]);

        return true; // Indicate success
    } catch (PDOException $e) {
        // Optionally log the error
        error_log($e->getMessage());
        return false; // Indicate failure
    }
}

function insertMessage($pdo, $senderId, $receiverId, $messageText) {
    $sql = 'INSERT INTO Message (text_m, sender_id, receiver_id) VALUES (:text_m, :sender_id, :receiver_id)';
    $parameters = [
        ':text_m' => $messageText,
        ':sender_id' => $senderId,
        ':receiver_id' => $receiverId
    ];
    return query($pdo, $sql, $parameters);
}

function getReceivedMessages($pdo, $userId) {
    $query = "
        SELECT m.*, u.name AS sender_name 
        FROM Message m
        JOIN user u ON m.sender_id = u.id
        WHERE m.receiver_id = ? 
        ORDER BY m.date DESC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([$userId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function updateUserProfile($pdo, $userId, $name, $email) {
    $sql = "UPDATE user SET name = :name, email = :email WHERE id = :id";
    $parameters = [
        ':name' => $name,
        ':email' => $email,
        ':id' => $userId
    ];
    return query($pdo, $sql, $parameters);
}

function getUserById($pdo, $userId) {
    try {
        $query = query($pdo, 'SELECT * FROM user WHERE id = ?', [$userId]);
        return $query->fetch(PDO::FETCH_ASSOC); // Return a single user as an associative array
    } catch (PDOException $e) {
        return []; // Return an empty array in case of an error
    }
}