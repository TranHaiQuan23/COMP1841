<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once __DIR__ . '/../includes/DatabaseConnection.php';
require_once __DIR__ . '/../includes/DatabaseFunctions.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle form submission
    $moduleName = trim($_POST['module_name']);

    if (!empty($moduleName)) {
        // Use the addModule function
        if (addModule($pdo, $moduleName)) {
            // Redirect to modules page with a success message
            header('Location: module.php?msg=Module added successfully');
            exit;
        } else {
            $error = 'An error occurred while adding the module.';
        }
    } else {
        $error = 'Module name cannot be empty.';
    }
}
?>