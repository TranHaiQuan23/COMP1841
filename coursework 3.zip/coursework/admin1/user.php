<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

require_once __DIR__ . '/../admin_base/admin_check.php';
require_once __DIR__ . '/../includes/DatabaseConnection.php';
require_once __DIR__ . '/../includes/DatabaseFunctions.php';

$users = getUser($pdo);

$avatar = getUserAvatar($pdo, $_SESSION['user_id']);
$GLOBALS['avatar'] = $avatar;
$title = 'Manage Users';
ob_start();
include __DIR__ . '/../templates/admin_user.html.php';
$output = ob_get_clean();
include __DIR__ . '/../templates/admin_layout.html.php';
?>