<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Include required files

require_once __DIR__ . '/../admin_base/admin_check.php';
require_once __DIR__ . '/../includes/DatabaseConnection.php';
require_once __DIR__ . '/../includes/DatabaseFunctions.php';


// Fetch only the logged-in user's image
$avatar = getUserAvatar($pdo, $_SESSION['user_id']);

$avatar = getUserAvatar($pdo, $_SESSION['user_id']);
$GLOBALS['avatar'] = $avatar;

$modules = getModule($pdo);
$title = 'Modules';
ob_start();
ob_start();
include __DIR__ . '/../templates/admin_module.html.php';
$output = ob_get_clean();
include __DIR__ . '/../templates/admin_layout.html.php';
?>
