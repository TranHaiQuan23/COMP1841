<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once __DIR__ . '/../admin_base/admin_check.php';
require_once __DIR__ . '/../includes/DatabaseConnection.php';
require_once __DIR__ . '/../includes/DatabaseFunctions.php';

if (isset($_POST['user_id'])) {
    try {
        // Get the user ID from the POST request
        $user_id = (int) $_POST['user_id'];

        if (deleteUser($pdo, $user_id)) {
            header('Location: admin_user.html.php'); 
            exit;
        } else {
            echo 'An error occurred while trying to delete the user.';
        }
    } catch (PDOException $e) {
        echo 'An error occurred: ' . htmlspecialchars($e->getMessage());
    }
} else {
    echo 'No user ID provided.';
}

ob_start();
include __DIR__ . '/../templates/admin_module.html.php';
$output = ob_get_clean();
include __DIR__ . '/../templates/admin_layout.html.php';
?>