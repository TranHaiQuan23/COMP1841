<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Include required files
require_once __DIR__ . '/../admin_base/admin_check.php';
require_once __DIR__ . '/../includes/DatabaseConnection.php';
require_once __DIR__ . '/../includes/DatabaseFunctions.php';

// Fetch only the logged-in user's image
$avatar = getUserAvatar($pdo, $_SESSION['user_id']);
$GLOBALS['avatar'] = $avatar;

$title = 'Questions';
$modules = getModule(($pdo));
$questions = getQuestions($pdo);
$totalQuestions = totalQuestions($pdo);



ob_start();
include __DIR__ . '/../templates/admin_question.html.php';
$output = ob_get_clean();
include __DIR__ . '/../templates/admin_layout.html.php';
?>
