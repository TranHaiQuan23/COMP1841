<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Include required files
require_once __DIR__ . '/login_base/check.php';
require_once __DIR__ . '/includes/DatabaseConnection.php';
require_once __DIR__ . '/includes/DatabaseFunctions.php';

if (isset($_POST['text_q'], $_POST['module_id'])) {
    try {
        // Image upload logic
        $target_dir = "images/";
        $originalFileName = basename($_FILES["fileToUpload"]["name"]);
        $imageFileType = strtolower(pathinfo($originalFileName, PATHINFO_EXTENSION));
        $newFileName = time() . '_' . $originalFileName; // Avoid filename conflicts
        $target_file = $target_dir . $newFileName;
        $uploadOk = 1;

        // Check if image file is an actual image
        if (isset($_FILES["fileToUpload"]) && $_FILES["fileToUpload"]["error"] == UPLOAD_ERR_OK) {
            $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
            if ($check === false) {
                error_log("File is not an image.");
                echo "File is not an image.";
                $uploadOk = 0;
            }

            // Check file size
            if ($_FILES["fileToUpload"]["size"] > 500000) {
                error_log("File too large.");
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }

            // Allow certain file formats
            if (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
                error_log("Invalid file format.");
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }

            // Attempt to upload file if all checks are passed
            if ($uploadOk == 1) {
                if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                    echo "The file " . htmlspecialchars($newFileName) . " has been uploaded.";
                } else {
                    error_log("Error uploading file.");
                    echo "Sorry, there was an error uploading your file.";
                }
            } else {
                echo "Sorry, your file was not uploaded due to previous errors.";
            }
        } else {
            error_log("File upload error: " . $_FILES["fileToUpload"]["error"]);
            echo "Error during file upload: " . $_FILES["fileToUpload"]["error"];
        }

        // Log the incoming data for debugging
        error_log("Inserting question: " . $_POST['text_q'] . ", Module ID: " . $_POST['module_id'] . ", Image: " . $newFileName);

        // Attempt to insert the question with the image path
        $insertSuccess = insertQuestion($pdo, $_POST['text_q'], $_SESSION['user_id'], $_POST['module_id'], $newFileName);

        // Check if the insert was successful
        if ($insertSuccess) {
            // Redirect after successful insertion
            header('Location: question.php');
            exit; // Always call exit after a redirect
        } else {
            $error = "Failed to add the question.";
            error_log($error); // Log the error
        }
    } catch (PDOException $e) {
        $error = 'An error occurred: ' . htmlspecialchars($e->getMessage());
        error_log($error); // Log the actual error message
    }
}

// Fetch only the logged-in user's image
$avatar = getUserAvatar($pdo, $_SESSION['user_id']);

$title = 'Questions';
ob_start();
include __DIR__ . '/templates/question.html.php';
$output = ob_get_clean();
include __DIR__ . '/templates/layout.html.php';
?>