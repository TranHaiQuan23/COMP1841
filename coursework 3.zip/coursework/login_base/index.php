<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: notauthorised.php");
    exit;
    
} else{
    header("Location: ../templates/index.php");
}
?>

