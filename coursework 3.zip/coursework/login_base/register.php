<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include database connection
require_once __DIR__ . '/../includes/DatabaseConnection.php';
require_once __DIR__ . '/../includes/DatabaseFunctions.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = trim($_POST['role'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');
    $image = trim($_POST['image'] ?? '');

    // Validate input
    if (empty($name) || empty($email) || empty($role) || empty($password) || empty($confirm_password) || empty($image)) {
        header("Location: signup.html?error=empty");
        exit;
    }

    // Check if password and confirm password match
    if ($password !== $confirm_password) {
        header("Location: signup.html?error=password_mismatch");
        exit;
    }

    // Check if email already exists
    $email_check = $pdo->prepare("SELECT * FROM user WHERE email = ?");
    $email_check->execute([$email]);

    if ($email_check->rowCount() > 0) {
        header("Location: signup.html?error=email_exists");
        exit;
    }


    // Prepare SQL query to insert user details
    $sql = "INSERT INTO user (name, email, role, password, image) VALUES (?, ?, ?, ?, ?)";
    
    try {
        // Prepare and execute the SQL statement
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$name, $email, $role, $password, $image]);

        // Redirect to a success page
        header("Location: login.html");
        exit;
    } catch (PDOException $e) {
        // Handle error
        die("Error: " . $e->getMessage());
    }
} else {
    header("Location: signup.html");
    exit;
}
?>