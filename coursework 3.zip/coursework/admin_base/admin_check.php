<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include the database functions
require_once __DIR__ . '/../includes/DatabaseConnection.php';
require_once __DIR__ . '/../includes/DatabaseFunctions.php'; // Include the functions file

if (!isset($_SESSION['user_id'])) {
    header("Location: admin_notauthorised.php");
    exit;
}

// Get the user role using the function
$userRole = getUserRole($pdo, $_SESSION['user_id']);
if ($userRole !== 'teacher') {
    header("Location: admin_notauthorised.php");
    exit;
}
?>