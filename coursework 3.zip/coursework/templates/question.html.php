<div class="container-question1">
    <form action="addquestion.php" method="post" enctype="multipart/form-data" class="question-form">


        <label for="fileToUpload"></label>
        <input type="file" name="fileToUpload" id="fileToUpload" class="styled-button" required>
        
        <br><br>

        <label for="text_q">What are you thinking right now? </label><br>

        <textarea name="text_q" rows="4" placeholder="Share your thoughts.." required></textarea>
        
        <br><br>

        <label for="module_id"></label>
        <select name="module_id" id="module_id" class="option-color1" required>
            <option value="">Select Module</option>
            <?php foreach ($modules as $module): ?>
                <option value="<?= htmlspecialchars($module['id'], ENT_QUOTES, 'UTF-8'); ?>">
                    <?= htmlspecialchars($module['name'], ENT_QUOTES, 'UTF-8'); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <br><br>
        <button type="submit" name="submit" class="styled-button2" value="Add">Submit</button>
    </form>
</div>

<div class="container-question2">
    <h5>Questions have been posted to the Question Portal: <?= htmlspecialchars($totalQuestions) ?></h5>
    <br>

    <?php if (!empty($questions)): ?>
        <?php foreach ($questions as $question): ?>
            <blockquote>
                <img class="avatar-circle" height="50px" src="images/<?= htmlspecialchars($question['image'], ENT_QUOTES, 'UTF-8') ?>" alt="User Avatar" />
                <?= htmlspecialchars($question['user_name'], ENT_QUOTES, 'UTF-8'); ?>
                <h10>From <?= htmlspecialchars($question['module_name'], ENT_QUOTES, 'UTF-8'); ?></h10>:
                <?= htmlspecialchars($question['text_q'], ENT_QUOTES, 'UTF-8') ?>
                <a href="updatequestion.php?id=<?= htmlspecialchars($question['id']); ?>">Edit</a>
                <br>
                <br><br>
                <img height="400px" src="images/<?= htmlspecialchars($question['image_q'], ENT_QUOTES, 'UTF-8') ?>" alt="Question Image" />                <br><br>
                <form action="deletequestion.php" method="POST" class="delete-form">
                    <input type="hidden" name="question_id" value="<?= htmlspecialchars($question['id']) ?>">
                    <input type="submit" class="styled-button1" value="Delete">
                </form>
                
            </blockquote>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No questions found.</p>
    <?php endif; ?>
</div>