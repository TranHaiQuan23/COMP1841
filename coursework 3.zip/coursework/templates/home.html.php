


    <div class="dashboard">Dashboard</div>
    <div class="container1">

    <div class="icon-group2">
            <img src="images/catvest.jpeg" alt="Question Icon" width="200px" height="200px"
            class="question-icon-fixed">
        </div>

        <div class="container-content1">User</div>
        <div class="container-content1-2">Show all user </div>
        <a href="user.php"><button class="nav-button1">></button></a>
    </div>


    <div class="container2">
    <div class="icon-group1">
           <img src="images/book.png" alt="Book Icon" class="avatar1">
        </div>

        <div class="container-content1">Course</div>
        <div class="container-content1-2">Show all courses in this website.</div>
        <a href="module.php"><button class="nav-button1">></button></a>
        
        
    </div>


    <div class="container3">
        
        <div class="icon-group2">
            <img src="images/question.png" alt="Question Icon" width="200px" height="200px"
            class="question-icon-fixed">
        </div>

        <div class="container-content1">Question</div>
        <div class="container-content1-2">Show all questions from students.</div>
        <a href="question.php"><button class="nav-button1">></button></a>
    </div>

    <div class="container4" >

        <div class="icon-group3">
            <img src="images/mailbox.png" alt="mailbox icon" width="200px" height="200px">
        </div>

        <div class="container-content1">Messages</div>
        <div class="container-content1-2">Read or contact to the teacher real quick.</div>
        <a href="message.php"><button class="nav-button1">></button></a>

    </div>

