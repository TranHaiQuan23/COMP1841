
<body>
    <div class="dashboard">Courses</div>
    <div class="container-module">
        <?php if(isset($error)): ?>
            <p> <?=$error ?> </p>
        <?php else:
            foreach($modules as $module): ?>
            
            <blockquote>
                <?=htmlspecialchars($module['name'], ENT_QUOTES, 'UTF-8')?>
            </blockquote>
                
        <?php endforeach;
        
        endif;
            
        ?>
    </div>
