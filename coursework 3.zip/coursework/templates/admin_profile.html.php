

<div class="container-question2">
    <div class="text4" >
    <blockquote>
    <img class="ava" src="<?= htmlspecialchars($avatar, ENT_QUOTES, 'UTF-8'); ?>" alt="User Avatar">
        <?= htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8'); ?>
        <h10>By <?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?></h10>
    </blockquote>
    </div>

    <div class="text3" >
    <h3>Edit Profile:</h3>
    <form action="" method="post">
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" value="<?= htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8'); ?>" required>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" value="<?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?>" required>

        <button type="submit">Update Profile</button>
    </form>
    </div>
</div>