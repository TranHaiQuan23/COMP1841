
<body>
    <div class="dashboard">Courses</div>
    <div class="container-module">
        <?php if(isset($error)): ?>
            <p> <?=$error ?> </p>
        <?php else:
            foreach ($modules as $module): ?>
                <blockquote>
                    <?= htmlspecialchars($module['name'], ENT_QUOTES, 'UTF-8') ?>
                    <a href="updatemodule.php?id=<?= htmlspecialchars($module['id']); ?>">Edit</a>
                    <form action="admin_deletemodule.php" method="POST" style="display:inline;">
                        <input type="hidden" name="module_id" value="<?= $module['id']; ?>">
                        <button type="submit" onclick="return confirm('Are you sure you want to delete this module?');">Delete</button>
                    </form>
                </blockquote>
            <?php endforeach;
        endif;
            
        ?>
        <form action="admin_addmodule.php" method="POST">
            <label for="module_name">+ Module Name:</label>
            <input type="text" id="module_name" name="module_name" required>
            <button type="submit">Add Module</button>
        </form>
    </div>
